// Comentário de linha

/*
Comentário de bloco...
Veja, pode ter quebra de linha.
*/

// Variáveis

// Operadores

// Condicional

// Loop

// Funções

// 